* https://www.jesusninoc.com/02/09/ejercicios-de-php-crear-un-formulario-y-enviar-valores-con-el-metodo-post/
