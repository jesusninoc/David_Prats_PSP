# Certificaciones de seguridad

- Sans 710: https://mega.nz/#!QNRxSaLY!sRHMVAyZ8f9Fqaq2O-g-5dVmU4WfIczgeaMz98kPGps
- Sans 560: http://certcollection.org/forum/topic/292558-mega-sans-560-network-penetration-testing/
- Sans 517: http://certcollection.org/forum/topic/292541-mega-sans-517-cutting-edge-hacking-techniques/
- Sans 531: http://certcollection.org/forum/topic/292540-mega-sans-531-sans-windows-command-line-kung-fu/
- Sans 617: http://certcollection.org/forum/topic/292539-mega-sans-617-wireless-ethical-hacking-penetration-testing-and-defenses/
- Sans 506: http://certcollection.org/forum/topic/292493-mega-sans-506-securing-linuxunix/
- Sans 508: http://certcollection.org/forum/topic/292127-mega-sans-508-advanced-digital-forensics-and-incident-response/
- Sans 503: http://certcollection.org/forum/topic/292121-mega-sans-503-intrusion-detection-in-depth/
- Sans 502: http://certcollection.org/forum/topic/292106-mega-sans-502-perimeter-protection-in-depth/
- Sans 401: http://certcollection.org/forum/topic/292086-mega-sans-401-security-essentials/
- Sans 610: http://certcollection.org/forum/topic/288694-mega-sans-610-reverse-engineering-malware/
- Sans 660: http://certcollection.org/forum/topic/288708-mega-sans-660-advanced-pentration-testing-exploits-gxpn/
- OSWP v3: http://certcollection.org/forum/topic/288500-mega-offsec-oswp-v3/page__hl__+oswp#entry1051472
- AWE v2: http://certcollection.org/forum/topic/288491-mega-offsec-awe-v2/page__hl__+offsec#entry1051454
- OSCE v1: http://certcollection.org/forum/topic/288492-mega-offsec-osce-v1/page__hl__+offsec#entry1051456
- OSCP v1: http://certcollection.org/forum/topic/288494-mega-offsec-oscp-v1/page__hl__+offsec#entry1051452
