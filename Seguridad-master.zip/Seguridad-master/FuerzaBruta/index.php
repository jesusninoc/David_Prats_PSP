<form id='login' action='postraw.php' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Acceso Especial</legend>
<label for='username' >Usuario :</label>
<input type='text' name='username' id='username'  maxlength="50" />
<label for='password' >Password :</label>
<input type='password' name='password' id='password' maxlength="50" />
<input type='submit' name='Submit' />
</fieldset>
</form>
