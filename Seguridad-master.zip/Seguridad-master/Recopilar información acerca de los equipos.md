# Windows Post Exploitation Cmdlets Execution (PowerShell)
https://www.jesusninoc.com/2016/10/09/windows-post-exploitation-cmdlets-execution-powershell/

# Hacking wifi with Powershell
https://www.jesusninoc.com/2015/02/11/hacking-wifi-with-powershell/

# Obtener serial de Windows con PowerShell
https://www.jesusninoc.com/2017/12/02/obtener-serial-de-windows-con-powershell/

# Almacenar entradas caché DNS en un fichero
https://www.jesusninoc.com/2016/10/21/almacenar-entradas-cache-dns-en-un-fichero/

# Enviar los datos recopilados por un canal seguro
https://www.jesusninoc.com/2017/04/30/enviar-datos-a-un-formulario-de-google-docs-desde-powershell-deducir-los-parametros-que-se-envian-por-post/
